"""Content GEO Score: score a page against the SE Content GEO Scoring Standard v2.1.

Run:  streamlit run app.py
"""
import json
import os
from pathlib import Path

import pandas as pd
import streamlit as st

from geoscore.capture import CaptureError, capture
from geoscore.catalog import PAGE_TYPES, STAGES, load_weights
from geoscore.explain import explain
from geoscore.judge import DEFAULT_MODEL, JudgeError, run_judge, to_calc_judge, verify_quotes

HERE = Path(__file__).resolve().parent
EXAMPLES = {
    "SE blog: cooling design, water, noise and permitting (71)": "blog_cooling_design_se.json",
    "SE calculator: data center power sizing (59, gate + penalties)": "calculator_power_sizing_se.json",
    "Medium blog: building agents in Copilot Studio (51)": "medium_copilot_studio_blog.json",
}
def _fmt(v):
    if isinstance(v, float) and v.is_integer():
        return str(int(v))
    return str(v)


DETECT = "Detect automatically from the target question"


def saved_api_key():
    """Key from .streamlit/secrets.toml, else the ANTHROPIC_API_KEY environment variable. Never shown."""
    try:
        key = st.secrets.get("ANTHROPIC_API_KEY", "")
        if key:
            return key, "the secrets file on this computer"
    except Exception:
        pass
    if os.environ.get("ANTHROPIC_API_KEY"):
        return os.environ["ANTHROPIC_API_KEY"], "the ANTHROPIC_API_KEY environment variable"
    return "", ""


BAND_COLORS = {"Excellent": "#0F766E", "Good": "#15803D", "Average": "#B45309", "Poor": "#B91C1C"}

st.set_page_config(page_title="Content GEO Score", page_icon=":bar_chart:", layout="wide")


# ---------- sidebar ----------
with st.sidebar:
    st.header("Setup")
    saved_key, key_source = saved_api_key()
    if saved_key:
        st.success(f"Using your saved Anthropic API key (from {key_source}).")
        override = st.text_input("Use a different key for this session (optional)", type="password", value="")
        api_key = override or saved_key
    else:
        st.warning("No saved API key found. Add it to .streamlit/secrets.toml (see README), or paste it below for this session only.")
        api_key = st.text_input("Anthropic API key", type="password", value="")
    model = st.selectbox("Judge model", [DEFAULT_MODEL, "claude-sonnet-5-5"], index=0,
                         help="Claude Opus 5.5 is recommended for judging.")
    effort = st.selectbox("Judge effort", ["high", "medium", "xhigh"], index=0,
                          help="Higher effort = more careful checks, slower and costlier.")
    st.caption(f"Standard: SE Content GEO Scoring Standard, weights {load_weights().get('version')}")
    st.caption("The AI judge only answers pass/fail checks with quotes. The score is calculated by code.")

st.title("Content GEO Score")
st.write("Score how ready a page's content is to be understood, trusted and quoted by AI answer engines, "
         "and see exactly how the score was calculated.")

tab_score, tab_replay = st.tabs(["Score a page", "Replay a saved judgement (no API call)"])

# ---------- intake ----------
with tab_score:
    type_keys = list(PAGE_TYPES)
    labels = [f"{PAGE_TYPES[k][0]}{'' if PAGE_TYPES[k][2] else '  (logic not yet tested on SE pages)'}" for k in type_keys]
    st.caption("Fields marked * are required. A target question is strongly recommended: the score checks whether the page answers it.")
    with st.form("intake"):
        url = st.text_input("Page URL *", placeholder="https://www.se.com/...  (or paste the page text below)")
        c1, c2 = st.columns(2)
        with c1:
            type_idx = st.selectbox("Content type *", range(len(type_keys)), format_func=lambda i: labels[i])
            type_key = type_keys[type_idx]
            stage_choice = st.selectbox("Buyer-journey stage *", [DETECT] + STAGES,
                                        help="Awareness: sees a problem. Education: learning how solutions work. Consideration: comparing options. "
                                             "Evaluation: checking specific products. Decision: ready to buy. "
                                             "'Detect automatically' picks the stage from your target question and the page.")
            topic = st.text_input("Topic *", placeholder="e.g. liquid cooling for AI data centers")
        with c2:
            ind = st.selectbox("Industry *", ["Data Centers & Networks", "Buildings (commercial)", "Homes (residential)", "Industrial Automation & Machine Builders",
                                              "Power Systems & Distribution", "Grid & Utilities", "Healthcare", "Infrastructure (water, transport)",
                                              "Energy Management & Sustainability", "Software (EcoStruxure, AVEVA)", "Services", "Other (type below)"])
            other_ind = st.text_input("Other industry (only if you chose Other)")
            industry = other_ind if ind.startswith("Other") else ind
            prompts = st.text_area("Target question(s) a buyer asks AI (recommended, one per line)", height=96,
                                   placeholder="How does direct liquid cooling work?\nLiquid vs air cooling for AI racks")
            c3, c4 = st.columns(2)
            audience = c3.text_input("Audience (optional)")
            country = c4.text_input("Country (optional)")
        with st.expander("Paste the page text instead (for pages that block automated requests or load content with JavaScript)"):
            pasted = st.text_area("Page text (mark headings with # if you can)", height=200)
        submitted = st.form_submit_button("Score page", type="primary")

    if submitted:
        detect = stage_choice == DETECT
        intake = {"url": url.strip(), "topic": topic.strip(), "industry": industry.strip(),
                  "stage": PAGE_TYPES[type_key][1] if detect else stage_choice, "detect_stage": detect,
                  "target_prompts": [p.strip() for p in prompts.splitlines() if p.strip()],
                  "audience": audience.strip(), "country": country.strip()}
        missing = [name for name, ok in (("Page URL or pasted page text", intake["url"] or (pasted or "").strip()),
                                         ("Topic", intake["topic"]), ("Industry", intake["industry"])) if not ok]
        if missing:
            st.error("Please fill in the required fields: " + ", ".join(missing) + ".")
        elif not api_key:
            st.error("Add your Anthropic API key (see the sidebar) to score a page. You can try the Replay tab without a key.")
        else:
            if not intake["target_prompts"]:
                st.warning("No target question given: the judge will infer one, and the result will say so.")
            with st.status("Scoring the page...", expanded=True) as status:
                try:
                    st.write("Capturing the page content...")
                    captured = capture(url=intake["url"] or None, pasted_text=pasted)
                    st.write(f"Captured {captured['signals'].get('word_count', 0):,} words from {captured['source']}.")
                    st.write(f"Judging every check with {model} (this can take 1-3 minutes)...")
                    judgement, usage = run_judge(api_key or None, model, effort, type_key, intake, captured)
                    st.write("Verifying every quote against the page...")
                    qv = verify_quotes(judgement, captured["text"])
                    judge_json = to_calc_judge(judgement, type_key, intake)
                    judge_json["capture"] = {"source": captured["source"], "notes": captured["notes"],
                                             "signals": captured["signals"], "title": captured["title"]}
                    judge_json["quote_check"] = qv
                    judge_json["usage"] = usage
                    st.session_state["judge"] = judge_json
                    st.session_state["page_text"] = captured["text"]
                    status.update(label="Scored.", state="complete", expanded=False)
                except (CaptureError, JudgeError) as e:
                    status.update(label="Could not score the page.", state="error")
                    st.error(str(e))

with tab_replay:
    st.write("Load a judgement saved earlier (or one of the examples) to see the full calculation without calling the API.")
    choice = st.selectbox("Example", ["(choose)"] + list(EXAMPLES))
    upload = st.file_uploader("...or upload a judge JSON", type=["json"])
    pasted_json = st.text_area("...or paste the JSON block from Copilot (or any AI tool) here. No API key needed.", height=150,
                               help="Use the Copilot prompt from the user guide. Copy the JSON block it returns at the end and paste it here.")
    if st.button("Show calculation"):
        if pasted_json.strip():
            raw = pasted_json.strip()
            if raw.startswith("```"):
                raw = raw.strip("`")
                raw = raw[raw.find("{"):]
            try:
                data = json.loads(raw[raw.find("{"): raw.rfind("}") + 1])
                data.setdefault("page", {}).setdefault("type", "article")
                data["page"].setdefault("stage", "Education")
                data["page"]["stage"] = str(data["page"]["stage"]).strip().capitalize()
                st.session_state["judge"] = data
                st.session_state["page_text"] = None
            except ValueError:
                st.error("That isn't valid JSON. Copy only the block between { and } from the AI tool's answer.")
        elif upload is not None:
            st.session_state["judge"] = json.load(upload)
            st.session_state["page_text"] = None
        elif choice in EXAMPLES:
            st.session_state["judge"] = json.loads((HERE / "examples" / EXAMPLES[choice]).read_text(encoding="utf-8"))
            st.session_state["page_text"] = None
        else:
            st.warning("Choose an example or upload a file.")


# ---------- results ----------
judge = st.session_state.get("judge")
if judge:
    try:
        ex = explain(judge)
    except SystemExit as e:  # the engine exits on unknown type/stage
        st.error(f"This judgement can't be scored: {e}")
        st.stop()
    r = ex["result"]
    page = judge.get("page", {})
    type_label = PAGE_TYPES.get(r["page_type_key"], (r["page_type_key"],))[0]
    st.divider()
    st.subheader(f"Result: {page.get('topic') or type_label}")
    if page.get("url"):
        st.caption(page["url"])
    st.caption(f"{type_label} · target question(s): {'; '.join(page.get('target_prompts') or []) or '(inferred)'}")
    how = {"detected": "detected from the target question and the page",
           "chosen": "chosen in the intake"}.get(page.get("stage_source"), "as recorded in the judgement")
    st.markdown(f"**Buyer-journey stage: {r['stage']}** ({how})" + (f": {page['stage_reason']}" if page.get("stage_reason") else ""))
    if page.get("stage_source") == "chosen" and page.get("detected_stage") and page["detected_stage"] != r["stage"]:
        st.caption(f"Note: from the target question and the page, the judge would place this at {page['detected_stage']}. "
                   "Re-run with that stage if it fits your intent better.")

    m1, m2, m3, m4, m5 = st.columns(5)
    m1.metric("Content GEO Score", f"{r['final_score']} / 100")
    m2.markdown(f"<div style='padding-top:6px'><span style='font-size:14px;color:#6B7480'>Band</span><br>"
                f"<span style='font-size:30px;font-weight:700;color:{BAND_COLORS.get(r['band'], '#1B2430')}'>{r['band']}</span></div>",
                unsafe_allow_html=True)
    m3.metric("Raw score", r["raw_score"])
    m4.metric("Penalties", f"-{r['penalty_points']}")
    m5.metric("Gate cap", r["cap"] if r["cap"] else "none", help=", ".join(r["gates_triggered"]) or None)
    ok = "meets" if r["meets_threshold"] else "is below"
    st.info(f"This page {ok} the 70 'Score is OK' bar. Confidence: {r['confidence']}. "
            f"{'Borderline: within 3 points of a band edge, so confirm with 3 independent runs. ' if any(abs(r['final_score'] - b) <= 3 for b in (40, 70, 90)) else ''}"
            "The score measures citation-readiness of the content only; actual AI citation also depends on retrieval, off-site reputation and technical access.")

    t1, t2, t3, t4, t5, t6 = st.tabs(["How the score was calculated", "Gates", "Penalties", "Where it fell short",
                                       "Evidence for every check", "Content & notes"])

    with t1:
        with st.expander("What are levels? (plain-language explanation)"):
            st.markdown(
                "Each criterion gets a **level from 0 to 5**, like a star rating: "
                "**0** missing · **1** barely there · **2** weak · **3** good enough · **4** strong · **5** best in class.  \n"
                "The level comes from the criterion's yes/no checklist: the more checks pass, the higher the level "
                "(level 5 only if every check passes and the evidence is exceptional). "
                "A few written rules then apply, e.g. 'key facts only in an image' keeps structure at 2 or below.  \n"
                "**Points = level / 5 x the criterion's weight.** A criterion worth 15.8 at level 3 earns 3/5 x 15.8 = 9.5 points; "
                "the other 6.3 points are 'lost' and are what a fix can win back.")
        st.markdown("**Step by step**")
        st.table(pd.DataFrame([(s, _fmt(v)) for s, v in ex["steps"]], columns=["Step", "Value"]).set_index("Step"))
        st.markdown(
            "1. **Checks:** each criterion has 3-5 pass/fail checks, answered with a quote.  \n"
            "2. **Level 0-5:** ceiling = share of checks passed x 5 (rounded half up; 5 only if all pass). "
            "The rubric's level-3/4 anchors and caps are then applied.  \n"
            "3. **Weights:** content-type weight x stage multiplier, rescaled to sum to 100 (= Effective weight).  \n"
            "4. **Points** = level / 5 x effective weight. **Lost** = what is still recoverable.  \n"
            "5. **Final** = raw - penalties (max -10), then the lowest triggered gate cap.")
        df = pd.DataFrame(ex["rows"])
        st.dataframe(df, hide_index=True, use_container_width=True,
                     column_config={"Points": st.column_config.NumberColumn(format="%.2f"),
                                    "Lost": st.column_config.NumberColumn(format="%.2f"),
                                    "Effective weight": st.column_config.NumberColumn(format="%.2f")})
        tot = df["Points"].sum()
        st.caption(f"Sum of points = {tot:.1f} (raw score). Universal criteria carry "
                   f"{df.loc[df['Kind'] == 'Universal', 'Effective weight'].sum():.0f}% of the weight on this page type; "
                   f"type-specific criteria {df.loc[df['Kind'] == 'Type-specific', 'Effective weight'].sum():.0f}%.")

    with t2:
        trig = [g for g in ex["gates"] if g["Status"] == "TRIGGERED"]
        if trig:
            st.error(f"{len(trig)} gate(s) triggered: " + ", ".join(f"{g['Gate']} ({g['Effect if triggered']})" for g in trig))
        else:
            st.success("No gate triggered.")
        st.write("Gates are deal-breakers. If one fires, the final score can't go above its cap, however good the rest is. "
                 "These are all the gates that apply to this content type:")
        st.table(pd.DataFrame(ex["gates"]).set_index("Gate"))

    with t3:
        appl = [p for p in ex["penalties"] if p["Status"] == "APPLIED"]
        st.write(f"Penalties are subtracted from the raw score, capped at -10 in total. Hidden AI instructions are always -10 and flagged. "
                 f"Applied here: **-{r['penalty_points']}**" + (f" ({', '.join(p['Penalty'] for p in appl)})." if appl else "."))
        st.table(pd.DataFrame(ex["penalties"]).set_index("Penalty"))

    with t4:
        st.write("Gaps ranked by the points you would recover. [Template / CMS] fixes are made once for every page; [Author] fixes are on this page.")
        for s in ex["shortfalls"][:8]:
            with st.expander(f"{s['id']} {s['name']}: +{s['lost']:.1f} points available (now level {s['level']})", expanded=s is ex["shortfalls"][0]):
                if s["rationale"]:
                    st.write(s["rationale"])
                for f in s["failed_checks"]:
                    st.markdown(f"- **{f['check']}** {f['description']}  \n  _{f['owner']}_ · {f['evidence']}")

    with t5:
        st.table(pd.DataFrame(ex["evidence"]))
        qc = judge.get("quote_check")
        if qc:
            st.caption(f"{qc['checked']} quotes checked against the page; {qc['failed']} not found and turned into fails.")

    with t6:
        cap = judge.get("capture") or {}
        for n in cap.get("notes", []):
            st.warning(n)
        obs = judge.get("out_of_scope_observations") or []
        if obs:
            st.markdown("**Out-of-scope observations (technical, not scored)**")
            for o in obs:
                st.markdown(f"- {o}")
        if page.get("inferred_fields"):
            st.markdown("**Inferred by the judge:** " + ", ".join(page["inferred_fields"]))
        if page.get("fan_outs"):
            st.markdown("**Follow-up questions judged:** " + " · ".join(page["fan_outs"]))
        if judge.get("usage"):
            u = judge["usage"]
            st.caption(f"Judge: {u.get('model')} · {u.get('input_tokens', 0):,} input tokens · {u.get('output_tokens', 0):,} output tokens")
        if st.session_state.get("page_text"):
            with st.expander("Captured page text"):
                st.text(st.session_state["page_text"][:20000])

    d1, d2 = st.columns(2)
    d1.download_button("Download judgement (JSON)", json.dumps(judge, ensure_ascii=False, indent=2), file_name="geo_judgement.json")
    d2.download_button("Download score result (JSON)", json.dumps(r, ensure_ascii=False, indent=2), file_name="geo_score_result.json")
