# Content GEO Score app

A Streamlit app that scores a page against the **SE Content GEO Scoring Standard v2.1** and shows exactly how the score was calculated:

- the content type's criteria (universal and type-specific), each check with its quote from the page
- every gate that applies to the content type, whether it fired, and why it exists
- every penalty, whether it applied, and the −10 cap
- the calculation: level per criterion → stage-adjusted weight → points → raw score → penalties → gate cap → final score
- where the page fell short, ranked by recoverable points and tagged template or author fix

The AI judge (Claude) only answers pass/fail checks with quotes. The score itself is computed by the same engine (`engine/geo_score_calc.py`, `engine/weights.json`) used for the 60-page SE pilot.

## Set up on any laptop (about 5 minutes, once)

1. **Install Python** 3.10 or newer from https://www.python.org/downloads/ (on Windows, tick "Add python.exe to PATH").
2. **Unzip** `geo-score-app.zip` anywhere, for example in Documents.
3. **Add your Anthropic API key** (only on your own laptop, never in a shared folder or chat):
   - In the `geo-score-app/.streamlit` folder, copy `secrets.toml.example` and name the copy `secrets.toml`.
   - Open `secrets.toml` in a text editor and replace `paste-your-key-here` with your key (from the Claude Console, API keys). Save.
   - (The folder starts with a dot, so it may be hidden: on Mac press Cmd+Shift+. in Finder; on Windows, View > Show > Hidden items.)
4. **Start the app:** double-click `start_mac.command` (Mac) or `start_windows.bat` (Windows). The first start installs what it needs (about a minute); then your browser opens http://localhost:8501.
   - Mac may say the file is from an unidentified developer: right-click it, choose Open, then Open again.

The app reads the key from `secrets.toml` (or from an `ANTHROPIC_API_KEY` environment variable) and never displays it. You can also paste a key in the sidebar for one session only.

Manual start, if you prefer the terminal:

```bash
cd geo-score-app
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
streamlit run app.py
```

## Using it

| Field | Required? | Why |
|---|---|---|
| Page URL (or pasted page text) | **Required** | The content to score |
| Content type | **Required** | Picks the criteria, weights and gates for that kind of page |
| Buyer-journey stage | **Required** (pre-set to "Detect automatically") | Changes how much each criterion counts. "Detect" picks the stage from your target question and the page, and the result explains why |
| Topic | **Required** | What the page should be about |
| Industry | **Required** | Shapes the follow-up questions and expected facts |
| Target question(s) | Strongly recommended | About a third of the score checks whether the page answers this question. If missing, the judge infers one and says so |
| Audience, country | Optional | Sharper language and standards checks (IEC vs UL) |

Click **Score page** (1-3 minutes), then read the tabs: *How the score was calculated*, *Gates*, *Penalties*, *Where it fell short*, *Evidence for every check*, *Content & notes*. The result always states the buyer-journey stage used and whether you chose it or it was detected. Download the judgement JSON to keep a record or replay it later without an API call.

**Sites that block automated requests** (se.com and Medium return HTTP 403 to the app): open the page in your browser, copy the article text and paste it under *Paste the page text instead*. Keep the URL filled in for the report. Mark headings with `#` if you can.

**Replay tab:** load one of the three examples (an SE blog at 71, the SE power-sizing calculator at 59 with a gate and penalties, the Medium Copilot Studio blog at 51) or any saved judgement to see the full calculation with no API call.

## Cost and data

- One page costs roughly **$0.30–0.60** on Claude Opus 5.5 at high effort (about 20–30K input tokens plus the judgement). The rubric is prompt-cached, so repeat runs on the same content type are cheaper.
- The page text is sent to the Anthropic API. Use an approved company key, and don't paste confidential or unreleased content into a tool your organisation hasn't approved.
- The app enables Anthropic's server-side refusal fallback; if a request is declined, it is retried on a recommended model. If the API rejects that option, the app retries without it.

## Status and limits

- **Tested:** page capture (server HTML and pasted text), quote verification, the calculation, gates, penalties and every screen, using the three replay examples and offline judgements. The engine reproduces the pilot scores exactly.
- **Not yet tested here:** a live judgement through the Anthropic API (the test machine's key had no credit). Run 2-3 pages you know first and compare with the pilot scores.
- Never share `secrets.toml` or commit it to Git (it is listed in `.gitignore`).
- The app scores the HTML the server returns. Pages that build their content with JavaScript will look thin: paste the rendered text instead.
- Content types marked *logic not yet tested on SE pages* (PDP, category, CaaS, editorial, document, datasheet, comparison, FAQ, glossary, video) give indicative scores.
- Scores within 3 points of 40, 70 or 90 are flagged as borderline: run them three times and use the median.
- The score measures citation-readiness of content only. Actual AI citation also depends on retrieval, off-site reputation and technical access.

## Files

| Path | What it is |
|---|---|
| `app.py` | Streamlit interface |
| `geoscore/capture.py` | Fetches the page, extracts the main content (article/main element), runs the content checker |
| `geoscore/judge.py` | Builds the rubric prompt for the content type, calls Claude with a JSON schema, verifies quotes |
| `geoscore/explain.py` | Runs the engine and builds the calculation, gates, penalties and shortfall views |
| `geoscore/catalog.py` | Content types, natural stages, gate scope, criterion names |
| `engine/` | The v2.1 scoring engine, weights and rubric references (unchanged copies) |
| `examples/` | Saved judgements for the Replay tab |
| `start_mac.command`, `start_windows.bat` | Double-click starters (set up on first run) |
| `.streamlit/secrets.toml.example` | Template for your API key |
