"""Page types, stages, gate scope and criterion names for the Content GEO Score (standard v2.1)."""
import json
import re
from pathlib import Path

ENGINE = Path(__file__).resolve().parent.parent / "engine"
REFS = ENGINE / "references"
WEIGHTS_PATH = ENGINE / "weights.json"

STAGES = ["Awareness", "Education", "Consideration", "Evaluation", "Decision"]

# key: (label, natural stage, tested on SE pages, logic file, section number in that file)
PAGE_TYPES = {
    "article": ("Blog / article", "Education", True, "page-types-v2.md", 1),
    "news": ("News / press release", "Consideration", True, "page-types-v2.md", 2),
    "solution": ("Solution / industry page", "Consideration", True, "page-types-v2.md", 3),
    "service": ("Service page (recurring)", "Consideration", True, "page-types-v2.md", 4),
    "service_project": ("Service page (project / modernization)", "Consideration", True, "page-types-v2.md", 4),
    "range": ("Product range", "Consideration", True, "page-types-v2.md", 5),
    "software_product": ("Software: product", "Evaluation", True, "page-types-v2.md", 6),
    "software_hub": ("Software: hub / portfolio", "Consideration", True, "page-types-v2.md", 6),
    "software_trial": ("Software: trial / download", "Decision", True, "page-types-v2.md", 6),
    "case_study": ("Customer story / case study", "Evaluation", True, "page-types-v2.md", 7),
    "calculator": ("Calculator / TradeOff Tool", "Consideration", True, "page-types-v2.md", 8),
    "whitepaper_gateway": ("White paper: download page", "Education", True, "page-types-v2.md", 9),
    "whitepaper_doc": ("White paper: document text (PDF)", "Education", True, "page-types-v2.md", 9),
    "esg_hub": ("Sustainability / ESG hub", "Evaluation", True, "page-types-v2.md", 10),
    "esg_report": ("Sustainability / ESG report: download page", "Evaluation", True, "page-types-v2.md", 10),
    "esg_report_doc": ("Sustainability / ESG report: document text (PDF)", "Evaluation", True, "page-types-v2.md", 10),
    "pdp": ("Product detail page (PDP)", "Evaluation", False, "page-types.md", 1),
    "category": ("Product category", "Consideration", False, "page-types.md", 3),
    "caas": ("CaaS / reusable content block", "Consideration", False, "page-types.md", 4),
    "editorial": ("Editorial page (common logic)", "Education", False, "page-types.md", 5),
    "document": ("Document: catalog / guide / manual", "Education", False, "page-types.md", 7),
    "datasheet": ("Document: datasheet", "Evaluation", False, "page-types.md", 7),
    "comparison": ("Comparison / selection guide", "Consideration", False, "page-types.md", 9),
    "faq": ("FAQ / support article", "Education", False, "page-types.md", 10),
    "glossary": ("Glossary / definition page", "Education", False, "page-types.md", 11),
    "video": ("Video page", "Education", False, "page-types.md", 13),
}

UNIVERSAL_GATES = ["G1", "G2", "G4", "G5", "G6", "G13"]
TYPE_GATES = {
    "G3": ["pdp", "datasheet"],
    "G7": ["article", "news"],
    "G8": ["case_study"],
    "G9": ["calculator"],
    "G10": ["range"],
    "G11": ["software_product", "software_trial"],
    "G12": ["service", "service_project"],
}

GATE_WHY = {
    "G1": "A contradiction makes every fact on the page untrustworthy.",
    "G2": "If the main question is never answered, nothing on the page can be quoted as the answer.",
    "G3": "A product page or datasheet without specs in text gives engines nothing to cite.",
    "G4": "Unsafe technical advice is a safety and reputation risk; an expert must review it.",
    "G5": "A title that promises what the body doesn't deliver is clickbait.",
    "G6": "Engines quote text; facts locked in images, video or PDFs are invisible to them.",
    "G7": "Dated content without a date can't be judged current; recency is a strong citation cue.",
    "G8": "A customer story without a measured result has no proof to quote.",
    "G9": "A calculator page that hides its method, assumptions and results has nothing to cite.",
    "G10": "A range page without a single rating or unit can't answer any selection question.",
    "G11": "Software pages must state at least deployment, integrations, security or licensing.",
    "G12": "A service page needs a concrete deliverable or a service level.",
    "G13": "On a page with almost no facts, 'neutral' and 'consistent' pass by default, so they are capped.",
}

PENALTY_INFO = {
    "hidden_instructions": ("Hidden AI instructions", "Text aimed at AI engines and hidden from readers. Always -10 and flagged."),
    "keyword_stuffing": ("Keyword stuffing", "The same phrases or questions repeated unnaturally."),
    "self_ranking": ("Self-ranking list", "A 'best X' list with our own brand first and no transparent criteria."),
    "superseded_no_notice": ("Superseded, no notice", "An older edition with no label or link to the newer one."),
    "fluff_density": ("Fluff", "More than 1.5 superlatives per 100 words of body text."),
    "boilerplate": ("Boilerplate", "More than 40% of the text shared with sibling pages."),
    "template_artifact": ("Template placeholder", "Live placeholder text ('lorem ipsum', 'ZZ_...') or a section rendered twice."),
    "cta_overload": ("CTA overload", "3 or more vague calls to action ('Learn more', 'Read more')."),
}

UNIVERSAL_NAMES = {
    "U1": "Answer-first & prompt alignment",
    "U2": "What / Who / When / Outcome",
    "U3": "Extractable structure & self-containment",
    "U4": "Factual density & specificity",
    "U5": "Evidence, attribution & expertise",
    "U6": "Follow-up (fan-out) coverage & focus",
    "U7": "Neutral, non-promotional tone",
    "U8": "Entity clarity & consistency",
    "U9": "Freshness & currency",
    "U10": "Journey-stage fit & next step",
}


def load_weights():
    return json.loads(WEIGHTS_PATH.read_text(encoding="utf-8"))


def _read(name):
    return (REFS / name).read_text(encoding="utf-8").replace("\r\n", "\n")


def section(file_name, number):
    """Return the markdown section '## <number>. ...' up to the next '## ' heading."""
    text = _read(file_name)
    m = re.search(r"^## %d\. .*?(?=^## \d+\. |\Z)" % number, text, flags=re.M | re.S)
    return m.group(0).strip() if m else ""


def _names_from(file_name):
    names = {}
    for line in _read(file_name).splitlines():
        m = re.match(r"^\|\s*([A-Z]{2,5}-\d+)\s*\|\s*([^|]+?)\s*\|", line)
        if m and m.group(1) not in names:
            names[m.group(1)] = m.group(2).strip()
    return names


def criterion_names(type_key):
    v2 = _names_from("page-types-v2.md")
    v1 = _names_from("page-types.md")
    primary, secondary = (v2, v1) if PAGE_TYPES[type_key][3] == "page-types-v2.md" else (v1, v2)
    names = dict(UNIVERSAL_NAMES)
    for cid in load_weights()["page_types"][type_key]:
        if cid not in names:
            names[cid] = primary.get(cid) or secondary.get(cid) or cid
    return names


def gates_for(type_key):
    """All gates that can fire on this page type, universal first."""
    scoped = [g for g, types in TYPE_GATES.items() if type_key in types]
    return UNIVERSAL_GATES + sorted(scoped, key=lambda g: int(g[1:]))
